const sumar = require("./sumar");
const restar = require("./restar");
const multiplicar = require("./multiplicar");
const dividir = require("./dividir");

module.exports = {
    sumar: sumar,
    restar : restar,
    multiplicar : multiplicar,
    dividir : dividir,
}