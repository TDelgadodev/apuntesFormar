const multiplicar = function(a,b){
    return a === 0 || b === 0 ? 0 : a * b;
}

module.exports = multiplicar;